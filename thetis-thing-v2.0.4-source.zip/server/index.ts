// ThetisThing Server v2.0.4 - TCI + CAT Hybrid Controller for Thetis SDR
// TCI for: VFO, Mode, TX, Split (what Thetis accepts)
// CAT for: NB, NR, ANF, AGC, Filter, RIT, Drive, Mic, VOX, Comp (what TCI doesn't accept)
// Author: DUDE TESTED
// Version: 2.0.4
// Fixes: Pretty watchlist popup (FlexThing style), 10min alert cooldown per callsign

import { DeskThing } from '@deskthing/server';
import WebSocket from 'ws';
import * as net from 'net';

// Define DESKTHING_EVENTS locally (not exported from @deskthing/server)
const DESKTHING_EVENTS = {
  MESSAGE: "message",
  DATA: "data",
  APPDATA: "appdata",
  CALLBACK_DATA: "callback-data",
  START: "start",
  STOP: "stop",
  PURGE: "purge",
  INPUT: "input",
  ACTION: "action",
  CONFIG: "config",
  SETTINGS: "settings",
  TASKS: "tasks",
  CLIENT_STATUS: "client_status"
} as const;

const SETTING_TYPES = {
  BOOLEAN: "boolean",
  NUMBER: "number", 
  STRING: "string",
  RANGE: "range",
  SELECT: "select",
  MULTISELECT: "multiselect",
  LIST: "list",
  RANKED: "ranked",
  COLOR: "color"
};

const BAND_FREQUENCIES: Record<string, number> = {
  "160m": 1900000, "80m": 3573000, "60m": 5357000, "40m": 7074000,
  "30m": 10136000, "20m": 14074000, "17m": 18100000, "15m": 21074000,
  "12m": 24915000, "10m": 28074000, "6m": 50313000
};

const MODES = ["USB", "LSB", "CW", "CW-R", "DIGU", "DIGL", "AM", "SAM", "FM", "NFM", "DRM", "RTTY"];
const TUNING_STEPS = [1, 10, 100, 1000, 10000];
const AGC_MODES = ["OFF", "LONG", "SLOW", "MED", "FAST"];
const NR_MODES = ["OFF", "NR", "NR2"];

let state = {
  connected: false, catConnected: false, radioName: "Thetis SDR", frequency: 14074000, mode: "USB",
  tuningStep: 100, tuningStepIndex: 2, txActive: false, sMeter: -100,
  txPower: 100, fwdPower: 0, swr: 1.0, micLevel: 0, voxEnabled: false,
  compEnabled: false, nbEnabled: false, nbLevel: 50, nrMode: 0,
  nrLevel: 50, anfEnabled: false, agcMode: "MED", agcModeIndex: 3,
  filterLow: 100, filterHigh: 2900, vfoBFrequency: 14074000,
  splitEnabled: false, ritEnabled: false, ritOffset: 0, xitEnabled: false, xitOffset: 0,
  memories: [
    { frequency: 14074000, mode: "DIGU", label: "FT8 20m" },
    { frequency: 7074000, mode: "DIGU", label: "FT8 40m" },
    { frequency: 3573000, mode: "DIGU", label: "FT8 80m" },
    { frequency: 10136000, mode: "DIGU", label: "FT8 30m" },
    { frequency: 14270000, mode: "USB", label: "SSB 20m" },
    { frequency: 7200000, mode: "LSB", label: "SSB 40m" },
    { frequency: 14060000, mode: "CW", label: "CW 20m" },
    { frequency: 7030000, mode: "CW", label: "CW 40m" }
  ]
};

let tciSocket: WebSocket | null = null;
let catSocket: net.Socket | null = null;
let reconnectTimeout: ReturnType<typeof setTimeout> | null = null;
let catReconnectTimeout: ReturnType<typeof setTimeout> | null = null;
let potaRefreshInterval: ReturnType<typeof setInterval> | null = null;
let catPollInterval: ReturnType<typeof setInterval> | null = null;
let handlersRegistered = false;
let isRunning = false; // Prevents reconnects after stop
let potaSpots: any[] = [];
let watchlist: string[] = [];
let alertedCallsigns: Map<string, number> = new Map(); // callsign -> last alert timestamp
const ALERT_COOLDOWN_MS = 10 * 60 * 1000; // 10 minutes
let settings = { thetis_ip: "127.0.0.1", thetis_port: 50001, cat_port: 13013, default_step: 100, callsign_watchlist: "" };
let catBuffer = "";

const sendStateToClient = () => { DeskThing.send({ type: "thetisState", payload: state }); };

// TCI send (for VFO, Mode, TX, Split)
const sendTCI = (cmd: string) => {
  if (tciSocket && tciSocket.readyState === WebSocket.OPEN) {
    const fullCmd = cmd.endsWith(';') ? cmd : cmd + ';';
    console.log("[ThetisThing] TCI TX: " + fullCmd);
    tciSocket.send(fullCmd);
  } else {
    console.log("[ThetisThing] TCI not connected");
  }
};

// CAT send (for DSP controls, power, etc.)
const sendCAT = (cmd: string) => {
  if (catSocket && !catSocket.destroyed) {
    const fullCmd = cmd.endsWith(';') ? cmd : cmd + ';';
    console.log("[ThetisThing] CAT TX: " + fullCmd);
    catSocket.write(fullCmd);
  } else {
    console.log("[ThetisThing] CAT not connected");
  }
};

const parseWatchlist = (str: string): string[] => {
  if (!str) return [];
  return str.split(',').map(c => c.trim().toUpperCase()).filter(c => c.length > 0);
};

// TCI Commands - using TCI 1.9 format (works: vfo, modulation, trx, split)
const setFrequency = (hz: number) => { state.frequency = hz; sendTCI("vfo:0,0," + hz); sendStateToClient(); };
const setMode = (mode: string) => { state.mode = mode; sendTCI("modulation:0," + mode.toLowerCase()); sendStateToClient(); };
const setTX = (on: boolean) => { state.txActive = on; sendTCI("trx:0," + (on ? 'true' : 'false')); sendStateToClient(); };
const setVfoB = (hz: number) => { state.vfoBFrequency = hz; sendTCI("vfo:0,1," + hz); sendStateToClient(); };
const setSplit = (on: boolean) => { state.splitEnabled = on; sendTCI("split_enable:0," + (on ? 'true' : 'false')); sendStateToClient(); };

// CAT Commands - ZZXX format (for everything TCI doesn't accept as input)
const setDrive = (level: number) => { 
  state.txPower = Math.max(0, Math.min(100, level)); 
  sendCAT("ZZPC" + state.txPower.toString().padStart(3, '0')); 
  sendStateToClient(); 
};

const setNB = (on: boolean) => { 
  state.nbEnabled = on; 
  sendCAT("ZZNA" + (on ? '1' : '0')); 
  sendStateToClient(); 
};

const setNR = (mode: number) => { 
  state.nrMode = mode;
  // ZZNR: 0=OFF, 1=NR, 2=NR2
  sendCAT("ZZNR" + mode);
  sendStateToClient(); 
};

const cycleNR = () => {
  const newMode = (state.nrMode + 1) % 3; // Cycle 0 -> 1 -> 2 -> 0
  setNR(newMode);
};

const setANF = (on: boolean) => { 
  state.anfEnabled = on; 
  sendCAT("ZZNT" + (on ? '1' : '0')); 
  sendStateToClient(); 
};

const setAGC = (modeIndex: number) => { 
  state.agcModeIndex = modeIndex; 
  state.agcMode = AGC_MODES[modeIndex]; 
  // ZZGT: 0=OFF, 1=LONG, 2=SLOW, 3=MED, 4=FAST
  sendCAT("ZZGT" + modeIndex); 
  sendStateToClient(); 
};

const setFilter = (low: number, high: number) => { 
  state.filterLow = low; 
  state.filterHigh = high;
  // ZZFL sets filter by index, but we can use ZZFH/ZZFL for high/low
  // Or use ZZFI for filter index. Let's use direct filter bounds
  sendCAT("ZZFL" + low.toString().padStart(5, '0'));
  sendCAT("ZZFH" + high.toString().padStart(5, '0'));
  sendStateToClient(); 
};

const setRIT = (on: boolean) => { 
  state.ritEnabled = on; 
  sendCAT("ZZRT" + (on ? '1' : '0')); 
  sendStateToClient(); 
};

const setRITOffset = (hz: number) => { 
  state.ritOffset = hz;
  // ZZRF format: +/-XXXXX (5 digits with sign)
  const sign = hz >= 0 ? '+' : '-';
  const absHz = Math.abs(hz).toString().padStart(5, '0');
  sendCAT("ZZRF" + sign + absHz); 
  sendStateToClient(); 
};

const setMicLevel = (level: number) => { 
  state.micLevel = Math.max(-40, Math.min(10, level));
  // ZZMG: signed format (-40 to +10 dB)
  const sign = state.micLevel >= 0 ? '+' : '';
  sendCAT("ZZMG" + sign + state.micLevel);
  sendStateToClient(); 
};

const setVox = (on: boolean) => { 
  state.voxEnabled = on; 
  sendCAT("ZZVX" + (on ? '1' : '0')); 
  sendStateToClient(); 
};

const setComp = (on: boolean) => { 
  state.compEnabled = on;
  // ZZCP: Compressor enable (ZZCL is Compander which is different)
  sendCAT("ZZCP" + (on ? '1' : '0')); 
  sendStateToClient(); 
};

// CAT Response Parser
const parseCAT = (data: string) => {
  catBuffer += data;
  const commands = catBuffer.split(';');
  catBuffer = commands.pop() || ""; // Keep incomplete command in buffer
  
  for (const cmd of commands) {
    if (cmd.length < 4) continue;
    const prefix = cmd.substring(0, 4);
    const value = cmd.substring(4);
    console.log("[ThetisThing] CAT RX: " + prefix + " = " + value);
    
    switch(prefix) {
      case 'ZZPC': // TX Power
        state.txPower = parseInt(value) || 0;
        break;
      case 'ZZNA': // NB
        state.nbEnabled = value === '1';
        break;
      case 'ZZNR': // NR mode (0=OFF, 1=NR, 2=NR2)
        state.nrMode = parseInt(value) || 0;
        break;
      case 'ZZNT': // ANF (Notch)
        state.anfEnabled = value === '1';
        break;
      case 'ZZGT': // AGC
        state.agcModeIndex = parseInt(value) || 0;
        state.agcMode = AGC_MODES[state.agcModeIndex] || "MED";
        break;
      case 'ZZFL': // Filter Low
        state.filterLow = parseInt(value) || 100;
        break;
      case 'ZZFH': // Filter High
        state.filterHigh = parseInt(value) || 2900;
        break;
      case 'ZZRT': // RIT enable
        state.ritEnabled = value === '1';
        break;
      case 'ZZRF': // RIT offset
        state.ritOffset = parseInt(value) || 0;
        break;
      case 'ZZMG': // Mic Gain (signed format: +10 or -40)
        state.micLevel = parseInt(value) || 0;
        break;
      case 'ZZVX': // VOX
        state.voxEnabled = value === '1';
        break;
      case 'ZZCP': // Compressor
        state.compEnabled = value === '1';
        break;
      default:
        // Check for SM0 S-meter response (format: SM0XXXX)
        if (cmd.startsWith('SM0') && cmd.length >= 7) {
          const smeterRaw = parseInt(cmd.substring(3, 7)) || 0;
          // Convert 0-30 scale to dBm (0=S0=-127dBm, 15=S9=-73dBm, 30=S9+60=-13dBm)
          // Each S-unit is ~6dB, S9=-73dBm
          if (smeterRaw <= 15) {
            state.sMeter = -127 + (smeterRaw * 3.6); // S0-S9
          } else {
            state.sMeter = -73 + ((smeterRaw - 15) * 4); // S9+
          }
        }
        break;
    }
  }
  sendStateToClient();
};

// TCI Parser - handles TCI 1.9 protocol responses
const parseTCI = (message: string) => {
  const commands = message.split(';').filter(cmd => cmd.trim());
  for (const cmdStr of commands) {
    const colonIndex = cmdStr.indexOf(':');
    if (colonIndex === -1) continue;
    const cmd = cmdStr.substring(0, colonIndex).trim().toLowerCase();
    const args = cmdStr.substring(colonIndex + 1).trim();
    const parts = args.split(',');
    console.log("[ThetisThing] TCI RX: " + cmd + ":" + args);
    
    switch(cmd) {
      case 'vfo':
        if (parts.length >= 3) {
          const rx = parseInt(parts[0]), sub = parseInt(parts[1]), freq = parseInt(parts[2]);
          if (rx === 0 && sub === 0) state.frequency = freq;
          else if (rx === 0 && sub === 1) state.vfoBFrequency = freq;
        }
        break;
      case 'modulation': 
        if (parts.length >= 2) {
          let mode = parts[1].toUpperCase();
          // Normalize mode names (TCI uses CWR, we use CW-R)
          if (mode === 'CWR') mode = 'CW-R';
          if (mode === 'CWL') mode = 'CW-L';
          state.mode = mode;
        }
        break;
      case 'trx': if (parts.length >= 2) state.txActive = parts[1].toLowerCase() === 'true'; break;
      case 'rx_smeter': if (parts.length >= 3) state.sMeter = parseFloat(parts[2]); break;
      case 'tx_power': if (parts[0]) state.fwdPower = parseFloat(parts[0]); break;
      case 'tx_swr': if (parts[0]) state.swr = parseFloat(parts[0]); break;
      case 'split_enable': if (parts.length >= 2) state.splitEnabled = parts[1].toLowerCase() === 'true'; break;
      case 'device': if (parts[0]) state.radioName = parts[0]; break;
      case 'protocol': console.log("[ThetisThing] TCI Protocol: " + args); break;
      case 'ready':
        console.log("[ThetisThing] TCI Ready!");
        // Query initial state via TCI (only what it supports)
        sendTCI("vfo:0,0"); sendTCI("vfo:0,1"); sendTCI("modulation:0"); sendTCI("trx:0");
        break;
      default: 
        // Don't log every unknown - many are just broadcasts we don't use
        break;
    }
  }
  sendStateToClient();
};

// TCI WebSocket Connection
const connectToThetis = () => {
  if (tciSocket) { try { tciSocket.close(); } catch (e) { } tciSocket = null; }
  const wsUrl = `ws://${settings.thetis_ip}:${settings.thetis_port}`;
  console.log("[ThetisThing] TCI connecting to " + wsUrl);
  try {
    tciSocket = new WebSocket(wsUrl);
    tciSocket.on('open', () => {
      console.log('[ThetisThing] TCI WebSocket connected');
      state.connected = true;
      sendStateToClient();
    });
    tciSocket.on('message', (data: WebSocket.Data) => { parseTCI(data.toString()); });
    tciSocket.on('close', () => {
      console.log('[ThetisThing] TCI WebSocket disconnected');
      state.connected = false;
      sendStateToClient();
      scheduleReconnect();
    });
    tciSocket.on('error', (err: Error) => {
      console.log('[ThetisThing] TCI WebSocket error: ' + err.message);
      state.connected = false;
      sendStateToClient();
    });
  } catch (err: any) {
    console.log('[ThetisThing] TCI connection error: ' + err.message);
    state.connected = false;
    scheduleReconnect();
  }
};

// CAT TCP Connection
const connectToCAT = () => {
  if (catSocket) { try { catSocket.destroy(); } catch (e) { } catSocket = null; }
  console.log("[ThetisThing] CAT connecting to " + settings.thetis_ip + ":" + settings.cat_port);
  
  catSocket = new net.Socket();
  catBuffer = "";
  
  catSocket.connect(settings.cat_port, settings.thetis_ip, () => {
    console.log('[ThetisThing] CAT TCP connected');
    state.catConnected = true;
    sendStateToClient();
    // Query initial state via CAT
    queryCATState();
    // Start polling for S-meter (1 second interval - Thetis closes connection after each request)
    if (catPollInterval) clearInterval(catPollInterval);
    catPollInterval = setInterval(pollCAT, 1000);
  });
  
  catSocket.on('data', (data: Buffer) => { parseCAT(data.toString()); });
  
  catSocket.on('close', () => {
    console.log('[ThetisThing] CAT TCP disconnected');
    state.catConnected = false;
    sendStateToClient();
    if (catPollInterval) { clearInterval(catPollInterval); catPollInterval = null; }
    scheduleCATReconnect();
  });
  
  catSocket.on('error', (err: Error) => {
    console.log('[ThetisThing] CAT TCP error: ' + err.message);
    state.catConnected = false;
    sendStateToClient();
  });
};

const queryCATState = () => {
  // Query all CAT-controlled parameters
  sendCAT("ZZPC;"); // TX Power
  sendCAT("ZZNA;"); // NB
  sendCAT("ZZNR;"); // NR (0=OFF, 1=NR, 2=NR2)  
  sendCAT("ZZNT;"); // ANF
  sendCAT("ZZGT;"); // AGC
  sendCAT("ZZFL;"); // Filter Low
  sendCAT("ZZFH;"); // Filter High
  sendCAT("ZZRT;"); // RIT
  sendCAT("ZZRF;"); // RIT Offset
  sendCAT("ZZMG;"); // Mic Gain
  sendCAT("ZZVX;"); // VOX
  sendCAT("ZZCP;"); // Compressor
};

const pollCAT = () => {
  // Poll S-meter periodically
  if (catSocket && !catSocket.destroyed) {
    sendCAT("SM0;"); // S-meter for VFO A (Kenwood format)
  }
};

const scheduleReconnect = () => {
  if (!isRunning) return; // Don't reconnect if stopped
  if (reconnectTimeout) clearTimeout(reconnectTimeout);
  reconnectTimeout = setTimeout(() => { 
    if (isRunning) { 
      console.log('[ThetisThing] TCI Reconnecting...'); 
      connectToThetis(); 
    }
  }, 5000);
};

const scheduleCATReconnect = () => {
  if (!isRunning) return; // Don't reconnect if stopped
  if (catReconnectTimeout) clearTimeout(catReconnectTimeout);
  catReconnectTimeout = setTimeout(() => { 
    if (isRunning) { 
      console.log('[ThetisThing] CAT Reconnecting...'); 
      connectToCAT(); 
    }
  }, 5000);
};

const disconnect = () => {
  if (reconnectTimeout) { clearTimeout(reconnectTimeout); reconnectTimeout = null; }
  if (catReconnectTimeout) { clearTimeout(catReconnectTimeout); catReconnectTimeout = null; }
  if (catPollInterval) { clearInterval(catPollInterval); catPollInterval = null; }
  if (tciSocket) { try { tciSocket.close(); } catch (e) { } tciSocket = null; }
  if (catSocket) { try { catSocket.destroy(); } catch (e) { } catSocket = null; }
  state.connected = false;
  state.catConnected = false;
};

// POTA
const fetchPotaSpots = async () => {
  try {
    console.log('[ThetisThing] Fetching POTA...');
    const response = await fetch('https://api.pota.app/spot/activator');
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const spots = await response.json();
    potaSpots = spots.slice(0, 100);
    console.log('[ThetisThing] Got ' + potaSpots.length + ' spots');
    if (watchlist.length > 0) {
      const now = Date.now();
      for (const spot of potaSpots) {
        const callUpper = (spot.activator || '').toUpperCase();
        if (watchlist.includes(callUpper)) {
          const lastAlert = alertedCallsigns.get(callUpper) || 0;
          if (now - lastAlert > ALERT_COOLDOWN_MS) {
            alertedCallsigns.set(callUpper, now);
            console.log('[ThetisThing] Watchlist alert for ' + callUpper + ' (next alert in 10 min)');
            DeskThing.send({ type: "watchlistAlert", payload: { 
              callsign: spot.activator, reference: spot.reference, parkName: spot.name,
              frequency: parseFloat(spot.frequency) * 1000, frequencyDisplay: spot.frequency, mode: spot.mode,
              spotTime: spot.spotTime || new Date().toISOString()
            }});
            break; // Only alert for ONE callsign per fetch cycle
          } else {
            console.log('[ThetisThing] Skipping alert for ' + callUpper + ' (cooldown active)');
          }
        }
      }
    }
    DeskThing.send({ type: "potaSpots", payload: potaSpots });
  } catch (err) { console.log('[ThetisThing] POTA error: ' + err); }
};
const doFetchSpots = () => { fetchPotaSpots(); };

// Memory
const recallMemory = (num: number) => {
  const idx = num - 1;
  if (idx >= 0 && idx < state.memories.length) {
    const mem = state.memories[idx];
    console.log("[ThetisThing] Recall M" + num);
    setFrequency(mem.frequency);
    setMode(mem.mode);
  }
};
const setModeDirect = (mode: string) => { setMode(mode); };
const setBandDirect = (band: string) => { const freq = BAND_FREQUENCIES[band]; if (freq) setFrequency(freq); };

// Settings
const initializeSettings = async () => {
  console.log('[ThetisThing] Init settings...');
  await DeskThing.initSettings({
    "thetis_ip": { id: "thetis_ip", type: SETTING_TYPES.STRING, value: "127.0.0.1", label: "Thetis IP Address" },
    "thetis_port": { id: "thetis_port", type: SETTING_TYPES.NUMBER, value: 50001, label: "Thetis TCI Port" },
    "cat_port": { id: "cat_port", type: SETTING_TYPES.NUMBER, value: 13013, label: "Thetis CAT Port" },
    "default_step": { id: "default_step", type: SETTING_TYPES.NUMBER, value: 100, label: "Default Tuning Step (Hz)" },
    "callsign_watchlist": { id: "callsign_watchlist", type: SETTING_TYPES.STRING, value: "", label: "POTA Watchlist (comma-separated)" },
    "memory_1": { id: "memory_1", type: SETTING_TYPES.STRING, value: "14074000,DIGU,FT8 20m", label: "Memory 1" },
    "memory_2": { id: "memory_2", type: SETTING_TYPES.STRING, value: "7074000,DIGU,FT8 40m", label: "Memory 2" },
    "memory_3": { id: "memory_3", type: SETTING_TYPES.STRING, value: "3573000,DIGU,FT8 80m", label: "Memory 3" },
    "memory_4": { id: "memory_4", type: SETTING_TYPES.STRING, value: "10136000,DIGU,FT8 30m", label: "Memory 4" },
    "memory_5": { id: "memory_5", type: SETTING_TYPES.STRING, value: "14270000,USB,SSB 20m", label: "Memory 5" },
    "memory_6": { id: "memory_6", type: SETTING_TYPES.STRING, value: "7200000,LSB,SSB 40m", label: "Memory 6" },
    "memory_7": { id: "memory_7", type: SETTING_TYPES.STRING, value: "14060000,CW,CW 20m", label: "Memory 7" },
    "memory_8": { id: "memory_8", type: SETTING_TYPES.STRING, value: "7030000,CW,CW 40m", label: "Memory 8" }
  });
  const saved = await DeskThing.getSettings();
  if (saved) {
    if (saved.thetis_ip?.value) settings.thetis_ip = saved.thetis_ip.value as string;
    if (saved.thetis_port?.value) settings.thetis_port = saved.thetis_port.value as number;
    if (saved.cat_port?.value) settings.cat_port = saved.cat_port.value as number;
    if (saved.default_step?.value) settings.default_step = saved.default_step.value as number;
    if (saved.callsign_watchlist?.value) settings.callsign_watchlist = saved.callsign_watchlist.value as string;
    state.tuningStep = settings.default_step;
    state.tuningStepIndex = TUNING_STEPS.indexOf(settings.default_step);
    if (state.tuningStepIndex === -1) state.tuningStepIndex = 2;
    for (let i = 1; i <= 8; i++) {
      const memStr = saved[`memory_${i}`]?.value as string;
      if (memStr) { const parts = memStr.split(','); if (parts.length >= 3) state.memories[i - 1] = { frequency: parseInt(parts[0]), mode: parts[1], label: parts[2] }; }
    }
    watchlist = parseWatchlist(settings.callsign_watchlist);
  }
  console.log('[ThetisThing] Settings done');
};

// Actions
const initializeActions = async () => {
  console.log('[ThetisThing] Init actions...');
  const actions = [
    { id: "tuneUp", name: "Tune Up", description: "Increase frequency", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "tuneDown", name: "Tune Down", description: "Decrease frequency", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "cycleStep", name: "Cycle Step", description: "Cycle tuning steps", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "cycleMode", name: "Cycle Mode", description: "Cycle modes", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "toggleTx", name: "Toggle TX", description: "TX on/off", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "tune", name: "Tune", description: "Low power tune", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "bandUp", name: "Band Up", description: "Next band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "bandDown", name: "Band Down", description: "Prev band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "toggleNB", name: "Toggle NB", description: "NB on/off", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "toggleNR", name: "Cycle NR", description: "OFF/NR/NR2", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "toggleANF", name: "Toggle ANF", description: "ANF on/off", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "cycleAGC", name: "Cycle AGC", description: "Cycle AGC", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "filterWider", name: "Filter Wider", description: "Widen filter", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "filterNarrower", name: "Filter Narrower", description: "Narrow filter", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "toggleRIT", name: "Toggle RIT", description: "RIT on/off", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "ritUp", name: "RIT Up", description: "+10 Hz", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "ritDown", name: "RIT Down", description: "-10 Hz", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "ritClear", name: "RIT Clear", description: "Clear RIT", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "toggleSplit", name: "Toggle Split", description: "Split on/off", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "swapAB", name: "Swap A/B", description: "Swap VFOs", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "copyAtoB", name: "A→B", description: "Copy A to B", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "powerUp", name: "Power Up", description: "+5 power", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "powerDown", name: "Power Down", description: "-5 power", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "toggleVox", name: "Toggle VOX", description: "VOX on/off", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "toggleComp", name: "Toggle COMP", description: "Compander on/off", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "micUp", name: "Mic Up", description: "+5 mic gain", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "micDown", name: "Mic Down", description: "-5 mic gain", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "memory1", name: "Memory 1", description: "Recall M1", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "memory2", name: "Memory 2", description: "Recall M2", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "memory3", name: "Memory 3", description: "Recall M3", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "memory4", name: "Memory 4", description: "Recall M4", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "memory5", name: "Memory 5", description: "Recall M5", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "memory6", name: "Memory 6", description: "Recall M6", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "memory7", name: "Memory 7", description: "Recall M7", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "memory8", name: "Memory 8", description: "Recall M8", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "screenVFO", name: "VFO Screen", description: "Go to VFO", tag: "nav", version: "1.0.0", version_code: 1, enabled: true },
    { id: "screenTX", name: "TX Screen", description: "Go to TX", tag: "nav", version: "1.0.0", version_code: 1, enabled: true },
    { id: "screenBAND", name: "BAND Screen", description: "Go to BAND", tag: "nav", version: "1.0.0", version_code: 1, enabled: true },
    { id: "screenMODE", name: "MODE Screen", description: "Go to MODE", tag: "nav", version: "1.0.0", version_code: 1, enabled: true },
    { id: "screenDSP", name: "DSP Screen", description: "Go to DSP", tag: "nav", version: "1.0.0", version_code: 1, enabled: true },
    { id: "screenMEM", name: "MEM Screen", description: "Go to MEM", tag: "nav", version: "1.0.0", version_code: 1, enabled: true },
    { id: "screenPOTA", name: "POTA Screen", description: "Go to POTA", tag: "nav", version: "1.0.0", version_code: 1, enabled: true },
    { id: "nextScreen", name: "Next Screen", description: "Next screen", tag: "nav", version: "1.0.0", version_code: 1, enabled: true },
    { id: "prevScreen", name: "Prev Screen", description: "Prev screen", tag: "nav", version: "1.0.0", version_code: 1, enabled: true },
    { id: "refreshPota", name: "Refresh POTA", description: "Refresh spots", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand160", name: "160m", description: "160m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand80", name: "80m", description: "80m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand60", name: "60m", description: "60m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand40", name: "40m", description: "40m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand30", name: "30m", description: "30m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand20", name: "20m", description: "20m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand17", name: "17m", description: "17m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand15", name: "15m", description: "15m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand12", name: "12m", description: "12m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand10", name: "10m", description: "10m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setBand6", name: "6m", description: "6m band", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setModeUSB", name: "USB", description: "USB mode", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setModeLSB", name: "LSB", description: "LSB mode", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setModeCW", name: "CW", description: "CW mode", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setModeDIGU", name: "DIGU", description: "DIGU mode", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setModeDIGL", name: "DIGL", description: "DIGL mode", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setModeAM", name: "AM", description: "AM mode", tag: "basic", version: "1.0.0", version_code: 1, enabled: true },
    { id: "setModeFM", name: "FM", description: "FM mode", tag: "basic", version: "1.0.0", version_code: 1, enabled: true }
  ];
  for (const action of actions) { await DeskThing.registerAction(action); }
  
  // Register keys for wheel/button mapping
  // IMPORTANT: Keys MUST have modes array specifying which EventMode values they handle
  // EventMode values: KeyUp=0, KeyDown=1, ScrollUp=2, ScrollDown=3, ScrollLeft=4, ScrollRight=5, 
  //                   SwipeUp=6, SwipeDown=7, SwipeLeft=8, SwipeRight=9, PressShort=10, PressLong=11
  const keys = [
    { 
      id: "scroll", 
      description: "Wheel scroll for tuning (map ScrollLeft→TuneDown, ScrollRight→TuneUp)",
      modes: [4, 5],  // ScrollLeft=4, ScrollRight=5
      version: "1.0.0"
    },
    { 
      id: "dialPress", 
      description: "Dial/wheel press (map to Cycle Step)",
      modes: [10, 11],  // PressShort=10, PressLong=11
      version: "1.0.0"
    }
  ];
  for (const key of keys) { 
    try { 
      await DeskThing.registerKey(key.id, key.description, key.modes, key.version); 
      console.log('[ThetisThing] Key "' + key.id + '" registered with modes: ' + JSON.stringify(key.modes)); 
    } catch (e: any) { 
      console.log('[ThetisThing] Key "' + key.id + '" error: ' + e.message); 
    } 
  }
  console.log('[ThetisThing] Actions done');
};

// Start
const start = async () => {
  console.log('[ThetisThing] Starting v2.0.2 (TCI + CAT Hybrid)...');
  isRunning = true;
  await initializeSettings();
  await initializeActions();
  sendStateToClient();
  if (!handlersRegistered) { handlersRegistered = true; console.log('[ThetisThing] Registering handlers...'); registerAllHandlers(); }
  connectToThetis();
  connectToCAT();
  doFetchSpots();
  potaRefreshInterval = setInterval(doFetchSpots, 60000);
};

// Handlers
const registerAllHandlers = () => {
  DeskThing.on(DESKTHING_EVENTS.SETTINGS, async (data: any) => {
    console.log('[ThetisThing] Settings updated');
    const newSettings = data?.payload || data;
    if (newSettings) {
      if (newSettings.thetis_ip?.value) settings.thetis_ip = newSettings.thetis_ip.value;
      if (newSettings.thetis_port?.value) settings.thetis_port = newSettings.thetis_port.value;
      if (newSettings.cat_port?.value) settings.cat_port = newSettings.cat_port.value;
      if (newSettings.callsign_watchlist?.value) { settings.callsign_watchlist = newSettings.callsign_watchlist.value; watchlist = parseWatchlist(settings.callsign_watchlist); }
      disconnect();
      connectToThetis();
      connectToCAT();
    }
  });
  DeskThing.on("getState", () => { sendStateToClient(); });
  DeskThing.on("getPotaSpots", () => { DeskThing.send({ type: "potaSpots", payload: potaSpots }); });
  
  // Scroll handlers - trying multiple event formats
  DeskThing.on("scroll", (data: any) => { 
    console.log('[ThetisThing] SCROLL event:', JSON.stringify(data));
    const direction = data?.payload?.direction || data?.direction || 0; 
    if (direction !== 0) {
      state.frequency += state.tuningStep * direction; 
      sendStateToClient(); 
      sendTCI("vfo:0,0," + state.frequency); 
    }
  });
  DeskThing.on("scrollLeft", (data: any) => { 
    console.log('[ThetisThing] scrollLeft event:', JSON.stringify(data));
    state.frequency -= state.tuningStep; 
    sendStateToClient(); 
    sendTCI("vfo:0,0," + state.frequency); 
  });
  DeskThing.on("scrollRight", (data: any) => { 
    console.log('[ThetisThing] scrollRight event:', JSON.stringify(data));
    state.frequency += state.tuningStep; 
    sendStateToClient(); 
    sendTCI("vfo:0,0," + state.frequency); 
  });
  DeskThing.on("wheelLeft", (data: any) => { 
    console.log('[ThetisThing] wheelLeft event:', JSON.stringify(data));
    state.frequency -= state.tuningStep; 
    sendStateToClient(); 
    sendTCI("vfo:0,0," + state.frequency); 
  });
  DeskThing.on("wheelRight", (data: any) => { 
    console.log('[ThetisThing] wheelRight event:', JSON.stringify(data));
    state.frequency += state.tuningStep; 
    sendStateToClient(); 
    sendTCI("vfo:0,0," + state.frequency); 
  });
  
  DeskThing.on("tuneToFreq", (data: any) => { const freq = data?.payload?.frequency || data?.frequency; let mode = data?.payload?.mode || data?.mode; if (freq) setFrequency(freq); if (mode) { mode = mode.toUpperCase(); if (['FT8', 'FT4', 'JS8', 'DATA', 'DIGI'].includes(mode)) mode = 'DIGU'; else if (mode === 'SSB') mode = freq > 10000000 ? 'USB' : 'LSB'; setMode(mode); } });
  DeskThing.on("tuneUp", () => { state.frequency += state.tuningStep; sendStateToClient(); sendTCI("vfo:0,0," + state.frequency); });
  DeskThing.on("tuneDown", () => { state.frequency -= state.tuningStep; sendStateToClient(); sendTCI("vfo:0,0," + state.frequency); });
  DeskThing.on("cycleStep", () => { state.tuningStepIndex = (state.tuningStepIndex + 1) % TUNING_STEPS.length; state.tuningStep = TUNING_STEPS[state.tuningStepIndex]; sendStateToClient(); });
  DeskThing.on("cycleMode", () => { const idx = MODES.indexOf(state.mode); setMode(MODES[(idx + 1) % MODES.length]); });
  DeskThing.on("toggleTx", () => { setTX(!state.txActive); });
  DeskThing.on("tune", () => { const origPower = state.txPower; setDrive(10); setTX(true); setTimeout(() => { setTX(false); setDrive(origPower); }, 3000); });
  DeskThing.on("bandUp", () => { const bands = Object.keys(BAND_FREQUENCIES); let idx = bands.findIndex(b => Math.abs(BAND_FREQUENCIES[b] - state.frequency) < 500000); if (idx < 0) idx = 0; idx = (idx + 1) % bands.length; setFrequency(BAND_FREQUENCIES[bands[idx]]); });
  DeskThing.on("bandDown", () => { const bands = Object.keys(BAND_FREQUENCIES); let idx = bands.findIndex(b => Math.abs(BAND_FREQUENCIES[b] - state.frequency) < 500000); if (idx < 0) idx = bands.length - 1; idx = (idx - 1 + bands.length) % bands.length; setFrequency(BAND_FREQUENCIES[bands[idx]]); });
  DeskThing.on("clientToggleNB", () => { setNB(!state.nbEnabled); });
  DeskThing.on("clientToggleNR", () => { cycleNR(); });
  DeskThing.on("clientToggleANF", () => { setANF(!state.anfEnabled); });
  DeskThing.on("toggleNB", () => { setNB(!state.nbEnabled); });
  DeskThing.on("toggleNR", () => { cycleNR(); });
  DeskThing.on("toggleANF", () => { setANF(!state.anfEnabled); });
  DeskThing.on("cycleAGC", () => { state.agcModeIndex = (state.agcModeIndex + 1) % AGC_MODES.length; setAGC(state.agcModeIndex); });
  DeskThing.on("filterWiden", () => { state.filterLow = Math.max(0, state.filterLow - 50); state.filterHigh = Math.min(4000, state.filterHigh + 50); setFilter(state.filterLow, state.filterHigh); });
  DeskThing.on("filterNarrow", () => { state.filterLow = Math.min(state.filterHigh - 100, state.filterLow + 50); state.filterHigh = Math.max(state.filterLow + 100, state.filterHigh - 50); setFilter(state.filterLow, state.filterHigh); });
  DeskThing.on("micUp", () => { setMicLevel(state.micLevel + 5); });
  DeskThing.on("micDown", () => { setMicLevel(state.micLevel - 5); });
  DeskThing.on("toggleVox", () => { setVox(!state.voxEnabled); });
  DeskThing.on("toggleComp", () => { setComp(!state.compEnabled); });
  DeskThing.on("powerUp", () => { setDrive(state.txPower + 5); });
  DeskThing.on("powerDown", () => { setDrive(state.txPower - 5); });
  DeskThing.on("toggleRIT", () => { setRIT(!state.ritEnabled); });
  DeskThing.on("ritUp", () => { setRITOffset(state.ritOffset + 10); });
  DeskThing.on("ritDown", () => { setRITOffset(state.ritOffset - 10); });
  DeskThing.on("ritClear", () => { setRITOffset(0); });
  DeskThing.on("toggleSplit", () => { setSplit(!state.splitEnabled); });
  DeskThing.on("swapAB", () => { const temp = state.frequency; setFrequency(state.vfoBFrequency); setVfoB(temp); });
  DeskThing.on("copyAtoB", () => { setVfoB(state.frequency); });
  DeskThing.on("setModeUSB", () => { setModeDirect("USB"); });
  DeskThing.on("setModeLSB", () => { setModeDirect("LSB"); });
  DeskThing.on("setModeCW", () => { setModeDirect("CW"); });
  DeskThing.on("setModeAM", () => { setModeDirect("AM"); });
  DeskThing.on("setModeFM", () => { setModeDirect("FM"); });
  DeskThing.on("setModeDIGU", () => { setModeDirect("DIGU"); });
  DeskThing.on("setModeDIGL", () => { setModeDirect("DIGL"); });
  DeskThing.on("setBand160", () => { setBandDirect("160m"); });
  DeskThing.on("setBand80", () => { setBandDirect("80m"); });
  DeskThing.on("setBand60", () => { setBandDirect("60m"); });
  DeskThing.on("setBand40", () => { setBandDirect("40m"); });
  DeskThing.on("setBand30", () => { setBandDirect("30m"); });
  DeskThing.on("setBand20", () => { setBandDirect("20m"); });
  DeskThing.on("setBand17", () => { setBandDirect("17m"); });
  DeskThing.on("setBand15", () => { setBandDirect("15m"); });
  DeskThing.on("setBand12", () => { setBandDirect("12m"); });
  DeskThing.on("setBand10", () => { setBandDirect("10m"); });
  DeskThing.on("setBand6", () => { setBandDirect("6m"); });
  DeskThing.on("setBand", (data: any) => { const band = data?.payload?.band || data?.band; if (band && BAND_FREQUENCIES[band]) setBandDirect(band); });
  DeskThing.on("recallMem", (data: any) => { recallMemory(data?.payload?.slot || data?.slot || 1); });
  DeskThing.on("memory1", () => { recallMemory(1); });
  DeskThing.on("memory2", () => { recallMemory(2); });
  DeskThing.on("memory3", () => { recallMemory(3); });
  DeskThing.on("memory4", () => { recallMemory(4); });
  DeskThing.on("memory5", () => { recallMemory(5); });
  DeskThing.on("memory6", () => { recallMemory(6); });
  DeskThing.on("memory7", () => { recallMemory(7); });
  DeskThing.on("memory8", () => { recallMemory(8); });
  DeskThing.on("screenVFO", () => { DeskThing.send({ type: "switchScreen", payload: { screen: "vfo" } }); });
  DeskThing.on("screenTX", () => { DeskThing.send({ type: "switchScreen", payload: { screen: "tx" } }); });
  DeskThing.on("screenBAND", () => { DeskThing.send({ type: "switchScreen", payload: { screen: "band" } }); });
  DeskThing.on("screenMODE", () => { DeskThing.send({ type: "switchScreen", payload: { screen: "mode" } }); });
  DeskThing.on("screenDSP", () => { DeskThing.send({ type: "switchScreen", payload: { screen: "dsp" } }); });
  DeskThing.on("screenMEM", () => { DeskThing.send({ type: "switchScreen", payload: { screen: "mem" } }); });
  DeskThing.on("screenPOTA", () => { DeskThing.send({ type: "switchScreen", payload: { screen: "pota" } }); });
  DeskThing.on("nextScreen", () => { DeskThing.send({ type: "nextScreen", payload: {} }); });
  DeskThing.on("prevScreen", () => { DeskThing.send({ type: "prevScreen", payload: {} }); });
  DeskThing.on("refreshPota", () => { fetchPotaSpots(); });
  DeskThing.on("potaScrollUp", () => { DeskThing.send({ type: "potaScroll", payload: { direction: -1 } }); });
  DeskThing.on("potaScrollDown", () => { DeskThing.send({ type: "potaScroll", payload: { direction: 1 } }); });

  // KEY handler for physical button/key events
  DeskThing.on("key", (data: any) => {
    console.log('[ThetisThing] KEY event:', JSON.stringify(data));
  });
  
  // INPUT handler 
  DeskThing.on(DESKTHING_EVENTS.INPUT, (data: any) => {
    console.log('[ThetisThing] INPUT event:', JSON.stringify(data));
  });
  
  // Button handler - handles physical buttons when app is FOCUSED
  DeskThing.on("button", (data: any) => {
    const button = data?.payload?.button || data?.button || data?.payload?.id || data?.id;
    const buttonState = data?.payload?.state || data?.state; // "down" or "up"
    console.log('[ThetisThing] BUTTON event: ' + button + ' state=' + buttonState);
    
    // Only act on button press (down), not release (up)
    if (buttonState === "up") return;
    
    switch (button) {
      case "Digit1": case "1": case "preset1":
        state.frequency -= state.tuningStep;
        sendStateToClient();
        sendTCI("vfo:0,0," + state.frequency);
        break;
      case "Digit2": case "2": case "preset2":
        state.frequency += state.tuningStep;
        sendStateToClient();
        sendTCI("vfo:0,0," + state.frequency);
        break;
      case "Digit3": case "3": case "preset3":
        state.tuningStepIndex = (state.tuningStepIndex + 1) % TUNING_STEPS.length;
        state.tuningStep = TUNING_STEPS[state.tuningStepIndex];
        sendStateToClient();
        break;
      case "Digit4": case "4": case "preset4":
        { const idx = MODES.indexOf(state.mode); setMode(MODES[(idx + 1) % MODES.length]); }
        break;
      case "Enter": case "select": case "dial": case "dialPress":
        setTX(!state.txActive);
        break;
      case "Escape": case "back":
        DeskThing.send({ type: "prevScreen", payload: {} });
        break;
      // Scroll wheel as button events
      case "ScrollLeft": case "scrollLeft": case "wheelLeft":
        state.frequency -= state.tuningStep;
        sendStateToClient();
        sendTCI("vfo:0,0," + state.frequency);
        break;
      case "ScrollRight": case "scrollRight": case "wheelRight":
        state.frequency += state.tuningStep;
        sendStateToClient();
        sendTCI("vfo:0,0," + state.frequency);
        break;
    }
    
    // Also check for mode property (docs say ScrollLeft=4, ScrollRight=5)
    const mode = data?.payload?.mode || data?.mode;
    if (mode === 4 || mode === "ScrollLeft") {
      console.log('[ThetisThing] BUTTON scroll mode 4 (left)');
      state.frequency -= state.tuningStep;
      sendStateToClient();
      sendTCI("vfo:0,0," + state.frequency);
    } else if (mode === 5 || mode === "ScrollRight") {
      console.log('[ThetisThing] BUTTON scroll mode 5 (right)');
      state.frequency += state.tuningStep;
      sendStateToClient();
      sendTCI("vfo:0,0," + state.frequency);
    }
  });

  // ACTION handler
  DeskThing.on(DESKTHING_EVENTS.ACTION, (data: any) => {
    const actionId = data?.payload?.id || data?.id;
    console.log('[ThetisThing] Action: ' + actionId);
    switch (actionId) {
      case "tuneUp": state.frequency += state.tuningStep; sendStateToClient(); sendTCI("vfo:0,0," + state.frequency); break;
      case "tuneDown": state.frequency -= state.tuningStep; sendStateToClient(); sendTCI("vfo:0,0," + state.frequency); break;
      case "cycleStep": state.tuningStepIndex = (state.tuningStepIndex + 1) % TUNING_STEPS.length; state.tuningStep = TUNING_STEPS[state.tuningStepIndex]; sendStateToClient(); break;
      case "cycleMode": { const idx = MODES.indexOf(state.mode); setMode(MODES[(idx + 1) % MODES.length]); } break;
      case "toggleTx": setTX(!state.txActive); break;
      case "tune": { const p = state.txPower; setDrive(10); setTX(true); setTimeout(() => { setTX(false); setDrive(p); }, 3000); } break;
      case "bandUp": { const bands = Object.keys(BAND_FREQUENCIES); let i = bands.findIndex(b => Math.abs(BAND_FREQUENCIES[b] - state.frequency) < 500000); if (i < 0) i = 0; i = (i + 1) % bands.length; setFrequency(BAND_FREQUENCIES[bands[i]]); } break;
      case "bandDown": { const bands = Object.keys(BAND_FREQUENCIES); let i = bands.findIndex(b => Math.abs(BAND_FREQUENCIES[b] - state.frequency) < 500000); if (i < 0) i = bands.length - 1; i = (i - 1 + bands.length) % bands.length; setFrequency(BAND_FREQUENCIES[bands[i]]); } break;
      case "toggleNB": setNB(!state.nbEnabled); break;
      case "toggleNR": cycleNR(); break;
      case "toggleANF": setANF(!state.anfEnabled); break;
      case "cycleAGC": state.agcModeIndex = (state.agcModeIndex + 1) % AGC_MODES.length; setAGC(state.agcModeIndex); break;
      case "filterWider": state.filterLow = Math.max(0, state.filterLow - 50); state.filterHigh = Math.min(4000, state.filterHigh + 50); setFilter(state.filterLow, state.filterHigh); break;
      case "filterNarrower": state.filterLow = Math.min(state.filterHigh - 100, state.filterLow + 50); state.filterHigh = Math.max(state.filterLow + 100, state.filterHigh - 50); setFilter(state.filterLow, state.filterHigh); break;
      case "toggleRIT": setRIT(!state.ritEnabled); break;
      case "ritUp": setRITOffset(state.ritOffset + 10); break;
      case "ritDown": setRITOffset(state.ritOffset - 10); break;
      case "ritClear": setRITOffset(0); break;
      case "toggleSplit": setSplit(!state.splitEnabled); break;
      case "swapAB": { const t = state.frequency; setFrequency(state.vfoBFrequency); setVfoB(t); } break;
      case "copyAtoB": setVfoB(state.frequency); break;
      case "powerUp": setDrive(state.txPower + 5); break;
      case "powerDown": setDrive(state.txPower - 5); break;
      case "toggleVox": setVox(!state.voxEnabled); break;
      case "toggleComp": setComp(!state.compEnabled); break;
      case "micUp": setMicLevel(state.micLevel + 5); break;
      case "micDown": setMicLevel(state.micLevel - 5); break;
      case "memory1": case "memory2": case "memory3": case "memory4": case "memory5": case "memory6": case "memory7": case "memory8": recallMemory(parseInt(actionId.replace("memory", ""))); break;
      case "setModeUSB": setModeDirect("USB"); break;
      case "setModeLSB": setModeDirect("LSB"); break;
      case "setModeCW": setModeDirect("CW"); break;
      case "setModeAM": setModeDirect("AM"); break;
      case "setModeFM": setModeDirect("FM"); break;
      case "setModeDIGU": setModeDirect("DIGU"); break;
      case "setModeDIGL": setModeDirect("DIGL"); break;
      case "setBand160": setBandDirect("160m"); break;
      case "setBand80": setBandDirect("80m"); break;
      case "setBand60": setBandDirect("60m"); break;
      case "setBand40": setBandDirect("40m"); break;
      case "setBand30": setBandDirect("30m"); break;
      case "setBand20": setBandDirect("20m"); break;
      case "setBand17": setBandDirect("17m"); break;
      case "setBand15": setBandDirect("15m"); break;
      case "setBand12": setBandDirect("12m"); break;
      case "setBand10": setBandDirect("10m"); break;
      case "setBand6": setBandDirect("6m"); break;
      case "screenVFO": DeskThing.send({ type: "switchScreen", payload: { screen: "vfo" } }); break;
      case "screenTX": DeskThing.send({ type: "switchScreen", payload: { screen: "tx" } }); break;
      case "screenBAND": DeskThing.send({ type: "switchScreen", payload: { screen: "band" } }); break;
      case "screenMODE": DeskThing.send({ type: "switchScreen", payload: { screen: "mode" } }); break;
      case "screenDSP": DeskThing.send({ type: "switchScreen", payload: { screen: "dsp" } }); break;
      case "screenMEM": DeskThing.send({ type: "switchScreen", payload: { screen: "mem" } }); break;
      case "screenPOTA": DeskThing.send({ type: "switchScreen", payload: { screen: "pota" } }); break;
      case "nextScreen": DeskThing.send({ type: "nextScreen", payload: {} }); break;
      case "prevScreen": DeskThing.send({ type: "prevScreen", payload: {} }); break;
      case "refreshPota": fetchPotaSpots(); break;
      default: console.log('[ThetisThing] Unknown: ' + actionId);
    }
  });
};

// Stop
const stop = async () => {
  console.log('[ThetisThing] Stopping...');
  isRunning = false;
  if (potaRefreshInterval) { clearInterval(potaRefreshInterval); potaRefreshInterval = null; }
  if (catPollInterval) { clearInterval(catPollInterval); catPollInterval = null; }
  if (reconnectTimeout) { clearTimeout(reconnectTimeout); reconnectTimeout = null; }
  if (catReconnectTimeout) { clearTimeout(catReconnectTimeout); catReconnectTimeout = null; }
  if (tciSocket) { try { tciSocket.close(); } catch (e) { } tciSocket = null; }
  if (catSocket) { try { catSocket.destroy(); } catch (e) { } catSocket = null; }
  state.connected = false;
  state.catConnected = false;
};

// Module registration
DeskThing.on(DESKTHING_EVENTS.START, start);
DeskThing.on(DESKTHING_EVENTS.STOP, stop);
