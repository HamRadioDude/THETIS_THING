// build.mjs - Build script for ThetisThing
import * as esbuild from 'esbuild';
import * as fs from 'fs';
import * as path from 'path';

const banner = `
import { createRequire as DeskThingCreateRequire } from 'module';
import { fileURLToPath as DeskThingFileURLToPath } from 'url';
import { dirname as DeskThingDirname } from 'node:path';

const require = DeskThingCreateRequire(import.meta.url);
const __filename = DeskThingFileURLToPath(import.meta.url);
const __dirname = DeskThingDirname(__filename);
`;

async function build() {
  console.log('[Build] Building server...');
  
  // Create dist directories
  fs.mkdirSync('dist/server', { recursive: true });
  fs.mkdirSync('dist/client/icons', { recursive: true });
  fs.mkdirSync('dist/icons', { recursive: true });
  
  // Build server with esbuild
  await esbuild.build({
    entryPoints: ['server/index.ts'],
    bundle: true,
    platform: 'node',
    format: 'esm',
    outfile: 'dist/server/index.js',
    banner: { js: banner }
  });
  
  console.log('[Build] Server built successfully');
  
  // Copy static files
  fs.copyFileSync('public/icons/thetis-thing.svg', 'dist/icons/thetis-thing.svg');
  fs.copyFileSync('public/icons/thetis-thing.svg', 'dist/client/icons/thetis-thing.svg');
  fs.copyFileSync('src/index.html', 'dist/client/index.html');
  fs.copyFileSync('deskthing/manifest.json', 'dist/manifest.json');
  
  // Create package.json files
  fs.writeFileSync('dist/package.json', '{"type": "module"}');
  fs.writeFileSync('dist/server/package.json', '{"type": "module"}');
  
  console.log('[Build] Static files copied');
  console.log('[Build] Build complete! Output in dist/');
}

build().catch(err => {
  console.error('[Build] Error:', err);
  process.exit(1);
});
