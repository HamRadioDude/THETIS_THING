# ThetisThing v1.0.1 - Source Code

**DeskThing app for controlling Thetis SDR via TCI protocol**

Works with Hermes-Lite 2, ANAN series, Red Pitaya, and all OpenHPSDR radios.

Created by **DUDE TESTED**

---

## Supported Radios

Any radio running **Thetis SDR software**, including:
- Hermes-Lite 2 (HL2)
- ANAN-10, ANAN-100, ANAN-200D, ANAN-7000DLE, ANAN-8000DLE
- Red Pitaya (with OpenHPSDR firmware)
- Angelia, Orion, Orion MKII
- Any OpenHPSDR Protocol 2 compatible radio

---

## Building from Source

### Prerequisites
- Node.js 18+ 
- npm

### Build Steps

```bash
# Install dependencies
npm install

# Build the server (bundles @deskthing/server SDK)
npm run build

# Create installable ZIP
npm run package
```

This creates `thetis-thing-v1.0.1.zip` ready to install in DeskThing.

---

## Project Structure

```
source/
├── deskthing/
│   └── manifest.json       # App metadata
├── public/
│   └── icons/
│       └── thetis-thing.svg
├── server/
│   └── index.ts            # TypeScript server source
├── src/
│   └── index.html          # Client UI (7 screens)
├── package.json            # Build configuration
├── build.mjs               # esbuild script
├── package.mjs             # ZIP creation script
└── README.md
```

---

## Critical DeskThing Patterns Used

This app follows all required patterns from the DeskThing Development Guide:

1. **DESKTHING_EVENTS enum** - Defined locally (not exported from SDK)
2. **initializeSettings() first** - Called before anything else in start()
3. **Async handlers** - start() and stop() are async
4. **Module-level START/STOP only** - All other handlers in registerAllHandlers()
5. **Handler guard** - handlersRegistered flag prevents duplicate registration
6. **Async in sync wrapper** - doFetchSpots() wraps fetchPotaSpots()
7. **Icon matches ID** - thetis-thing.svg matches manifest id
8. **package.json type: module** - Both root and server have it
9. **NO modes in key registration** - Only id and description

---

## Features

### 7 Control Screens
1. **VFO** - Large frequency display, S-meter, mode, step
2. **TX** - Power, SWR, mic gain, VOX, compressor, tune
3. **BAND** - Quick band selection (160m - 6m)
4. **MODE** - All operating modes
5. **DSP** - NB, NR, ANF, AGC, filter controls
6. **MEM** - 8 memory channels
7. **POTA** - Live Parks on the Air spots with watchlist alerts

### TCI Protocol
- Full TCP client for Thetis TCI server
- Automatic reconnection on disconnect
- Bidirectional command/response handling

### POTA Integration
- Fetches live spots from api.pota.app
- Filters by current mode
- Callsign watchlist with popup alerts

---

## Thetis TCI Setup

1. Open **Thetis** on your PC
2. Go to **Setup** → **Serial/Network/Midi CAT** → **Network**
3. Enable **TCI Server**
4. Note the port (default: 50001)
5. Click **Apply**

---

## Settings

| Setting | Default | Description |
|---------|---------|-------------|
| thetis_ip | 127.0.0.1 | Thetis PC IP address |
| thetis_port | 50001 | TCI server port |
| default_step | 100 | Tuning step in Hz |
| callsign_watchlist | (empty) | Comma-separated calls for POTA alerts |
| memory_1-8 | Various | Format: freq,mode,label |

---

## TCI Commands Implemented

| Function | TCI Command |
|----------|-------------|
| Set Frequency | VFO:0,{hz}; |
| Set Mode | MODULATION:0,{mode}; |
| TX On/Off | TRX:0,{true/false}; |
| Set Power | DRIVE:{0-100}; |
| Noise Blanker | RX_NB:0,{true/false}; |
| Noise Reduction | RX_NR:0,{true/false}; |
| Auto Notch | RX_ANF:0,{true/false}; |
| AGC Mode | RX_AGC:0,{0-4}; |
| Filter | RX_FILTER_BAND:0,{low},{high}; |
| Split | SPLIT:0,{true/false}; |
| RIT | RIT:0,{true/false}; |
| RIT Offset | RIT_OFFSET:0,{hz}; |

---

## License

MIT License - Free to use and modify.

73 de DUDE TESTED
