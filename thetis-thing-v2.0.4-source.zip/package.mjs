// package.mjs - Create installable ZIP
import * as fs from 'fs';
import { execSync } from 'child_process';

console.log('[Package] Creating installable ZIP...');

// Read version from manifest
const manifest = JSON.parse(fs.readFileSync('dist/manifest.json', 'utf8'));
const version = manifest.version;
const filename = `thetis-thing-v${version}.zip`;

// Create ZIP
try {
  execSync(`cd dist && zip -r ../${filename} .`, { stdio: 'inherit' });
  console.log(`[Package] Created ${filename}`);
} catch (err) {
  console.error('[Package] Error creating ZIP:', err);
  process.exit(1);
}
